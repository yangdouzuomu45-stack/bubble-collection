吹き出しコレクション - GitHub Pages 公開手順

1. GitHubにログインし、New repository から新しいリポジトリを作成します。
2. Repository name は bubble-collection などにします。
3. Public を選んで作成します。
4. Add file → Upload files から、このZIP内の index.html をアップロードします。
   ※ ZIPのままではなく、解凍して index.html をアップロードしてください。
5. Commit changes を押します。
6. リポジトリの Settings → Pages を開きます。
7. Build and deployment の Source を Deploy from a branch にします。
8. Branch は main、フォルダーは /(root) を選び、Save を押します。
9. 数分待つと、Settings → Pages に公開URLが表示されます。
   通常は https://GitHubユーザー名.github.io/bubble-collection/ です。

注意:
・公開サイトは誰でも見られます。吹き出しアプリ自体には登録内容をサーバーへ送る機能はなく、
  登録データは利用中のブラウザ内に保存されます。
・別の端末やブラウザとは同期されません。「データを書き出す」でバックアップし、
  別端末では「データを読み込む」を使ってください。
